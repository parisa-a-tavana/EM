function u=icfun(x)
 u=x;
end
