function [pl,ql,pr,qr]=bcfun(xl,ul,xr,ur,t)
 pl=ul
 pr=ur;
 ql=0;
 qr=0;
end
